({
	doInit : function(component, event, helper) {
		var nav = $A.get("e.force:navigateToComponent");
        nav.setParams({
            componentDef : "c:InspectionQuestionListOnly",
            componentAttributes: {
                AssessmentId : component.get("v.recordId"),
                showHeader : true                
            }
        });
        nav.fire();     
	}
})