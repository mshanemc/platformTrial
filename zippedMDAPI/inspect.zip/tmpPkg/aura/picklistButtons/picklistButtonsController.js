({
    setValue : function(component, event, helper) {
        var record = component.get("v.record");
        record[component.get("v.field")] = event.target.title;
        component.set("v.record", record);

        component.set("v.value", event.target.title);

        var action = component.get("v.onchange");
        $A.enqueueAction(action);
    },

    doInit : function(component) {
        var record = component.get("v.record");
        component.set("v.value", record[component.get("v.field")]);
    },
})
