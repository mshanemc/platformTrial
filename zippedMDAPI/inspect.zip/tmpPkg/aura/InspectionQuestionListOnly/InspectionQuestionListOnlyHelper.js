/* globals _ */
({
    getQuestions : function(component) {
        console.log('getting questions');
        //get the questions
        let action = component.get("c.getQuestions"); //get from apex
        action.setParams({
            "AssessmentId" : component.get("v.AssessmentId")
        });
        action.setCallback(this, function (a){

            if (component.isValid()){
                let questions = a.getReturnValue();
                if (questions.length>0){
                    //do we have categories?  If so, let's use them
                    component.set("v.groupByCategory", _.every(questions, 'Category__c'));
                    component.set("v.assessmentName", questions[0].Inspection__r.Name);

                    if (component.get("v.groupByCategory")){
                        let qByCat = [];
                        let uniqs = _.uniq(_.map(questions, "Category__c"));
                        for (let i = 0; i<uniqs.length; i++){
                            qByCat.push({
                                "Name" : uniqs[i],
                                "Questions" : _.filter(questions, {"Category__c" : uniqs[i]}),
                                "doneQuestions" : null
                            });
                        }
                        component.set("v.qByCat", qByCat);
                    }

                    component.set("v.questions", questions);
                    component.set("v.receivedQuestions", true);
                }
            } else {
                console.log("component wasn't valid, so question callback skipped.");
            }

        });
        $A.enqueueAction(action);
    },

    getDescribe:  function (component, objectName, whereToPut){
        let action = component.get("c.describe");
        action.setParams({"objtype": objectName});
        action.setCallback(this, function (a){
            let state = a.getState();
            if (state === "SUCCESS" && component.isValid()) {
                whereToPut = "v." +  whereToPut;
                component.set(whereToPut, JSON.parse(a.getReturnValue()));
            }  else if (state === "ERROR") {
                let appEvent = $A.get("e.c:handleCallbackError");
                appEvent.setParams({
                    "errors" : a.getError()
                });
                appEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },

    updateCounts : function(component){
        //console.log("counts updating");
        if (component.get("v.groupByCategory")){
            //console.log('its categories!!')
            let qByCat = component.get("v.qByCat");
            let qByCatNew = [];
            //for each category

            let updated = false;

            for (let i = 0; i<qByCat.length; i++){
                let done = this.countDone(qByCat[i].Questions, component);
                if (qByCat[i].doneQuestions !== done){
                    qByCat[i].doneQuestions = done;
                    updated = true;
                }
                qByCatNew.push(qByCat[i])
            }

            if (updated){
                component.set("v.qByCat", qByCatNew);
            }

            //for the whole
            let allQ = _.flatten(_.map(qByCat, "Questions"));
            //console.log(allQ);
            component.set("v.totalQuestions", allQ.length);
            component.set("v.doneQuestions", this.countDone(allQ, component));
        } else {
            //no categories
            let questions = component.get("v.questions");
            component.set("v.totalQuestions", questions.length);
            component.set("v.doneQuestions", this.countDone(questions, component));
        }
    },

    //returns the non-null ratings
    countDone : function(questions, component){
        let questionsShadow = component.get("v.questionsShadow");
        let doneCount = _.filter(questions, function (x){
            return questionsShadow[x.Id] && !$A.util.isUndefinedOrNull(questionsShadow[x.Id].response)
        }).length;
        return doneCount;
    },

    navToRecord : function(component){
        let navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": component.get("v.AssessmentId")
        });
        navEvt.fire();
    }

})