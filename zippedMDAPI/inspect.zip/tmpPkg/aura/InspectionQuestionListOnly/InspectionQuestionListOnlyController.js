({
    doInit : function(component, event, helper) {
        helper.getQuestions(component);
    },

    //sends a null back to the parent component, who then would render the inspection list again
    showAssessmentList: function(component, event, helper){
        $A.get("e.force:navigateToObjectHome")
        .setParams({
            "scope": "Inspection__c"
        }).fire();
    },

    selectCat : function (component, event){
        if (component.get("v.selectedCat")===event.target.id){
            component.set("v.selectedCat", "empty");
        } else {
            component.set("v.selectedCat", event.target.id);
        }
    },

    handleQuestionUpdate : function (component, event, helper){
        console.log("heard an update to questions");
        // add to our shadow questions
        let questionsShadow = component.get("v.questionsShadow") || {};
        questionsShadow[event.getParam("recordId")] = {
            "response": event.getParam("response")
        }
        component.set("v.questionsShadow", questionsShadow);
        helper.updateCounts(component);
        console.log(questionsShadow);

    },

    nav: function (component, event, helper){
        helper.navToRecord(component);
    },

    left : function(component, event, helper) {
        component.destroy();
    },


})