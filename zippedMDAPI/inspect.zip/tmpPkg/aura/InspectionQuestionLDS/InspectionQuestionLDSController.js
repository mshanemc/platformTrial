({
	recordChange : function(component, event, helper) {
		// console.log("record change");
		console.log(event.getParams().changeType);

		//everything is back
		if (component.get("v.objectInfo") && component.get("v.objectInfo").fields.length > 0 && component.get("v.question") && component.get("v.question").Response_Field__c){
			//only once, unless hit from the save method. Avoid re-initing
			if (!component.get("v.inited")){
				component.set("v.inited", true);
				helper.countStuff(component);
				helper.setPanelStyle(component);
				let responseField = component.get("v.question").Response_Field__c;
				// console.log('responseField is ' + responseField);

				let responseFieldMeta = component.get("v.objectInfo").fields.find((field) => { return field.name === responseField })
				// console.log('found field');

				console.log(responseFieldMeta);
				console.log(responseFieldMeta.type);

				component.set("v.fieldType", responseFieldMeta.type);
				if (responseFieldMeta.type === 'picklist'){
					component.set("v.picklistValues", responseFieldMeta.picklistOptions);
				}
			}
		} else {
			// console.log("metadata not ready");
		}
	},

	save : function(component, event, helper) {
		// console.log('saving...');
		helper.countStuff(component);
		helper.setPanelStyle(component);

		component.find("question").saveRecord(
			$A.getCallback(function(saveResult){
				//console.log(saveResult);
				if (saveResult.state === "SUCCESS"){
					//happy logic here
					component.find("question").reloadRecord();
					var evt = $A.get("e.c:InspectionEvent");
					evt.setParams({
						"eventType": "Response",
					});
					evt.fire();
				} else if (saveResult.state === "INCOMPLETE") {
					console.log('User is offline, device doesn\'t support drafts.');
				} else if (saveResult.state === "ERROR"){
					component.find("leh").passErrors(saveResult.error);
				}
			})
		);
	},

	navFeed : function(component, event, helper) {
		var navEvt = $A.get("e.force:navigateToSObject");
		navEvt.setParams({
			"recordId": component.get("v.question").Id,
			"slideDevName": "chatter"
		});
		navEvt.fire();
	},

	handleUploadFinished : function(component, event, helper) {
		var uploadedFiles = event.getParam("files");
		let files = component.get("v.files");
		files.push(uploadedFiles);
		component.set("v.files", files);
	},

	doInit : function(component, event, helper) {
		console.log(`question ${component.get("v.questionId")} is being inited`);
	},

	left: function (component, event, helper) {
		component.destroy();
	}

})