({
	countStuff : function(component) {
		let responseField = component.get("v.question").Response_Field__c;

		// component.find("question").reloadRecord();
		var evt = $A.get("e.c:InspectionEvent");
		evt.setParams({
			"eventType": "Response",
			"recordId": component.get("v.questionId"),
			"response": component.get("v.question")[responseField]
		});
		evt.fire();
	},

	setPanelStyle: function (component) {

		var question = component.get("v.question");
		let responseField = component.get("v.question").Response_Field__c;
		let response = component.get("v.question")[responseField];


		if (question.Green_Text__c && question.Green_Text__c.includes(response)) {
			component.set("v.panelStyle", "slds-card__header slds-theme_success");
		} else if (question.Yellow_Text__c && question.Yellow_Text__c.includes(response)) {
			component.set("v.panelStyle", "slds-card__header slds-theme_warning");
		} else if (question.Red_Text__c && question.Red_Text__c.includes(response)) {
			component.set("v.panelStyle", "slds-card__header slds-theme_error");
		} else {
			component.set("v.panelStyle", "slds-card__header slds-theme_shade");
		}
	}
})