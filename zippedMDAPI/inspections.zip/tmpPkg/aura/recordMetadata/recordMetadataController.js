({
    doInit : function(component) {
        var action = component.get("c.describe");
        action.setStorable();
        action.setParams({
            objtype : component.get("v.objectName")
        });
        action.setCallback(this, function(a){
            var state = a.getState();
            if (state === "SUCCESS") {
                let response = JSON.parse(a.getReturnValue());
                console.log(response);
                component.set("v.objectInfo", response);
            } else if (state === "ERROR") {
                console.log(a.getError());
            }
        });
        $A.enqueueAction(action);
    }
})
